import React from "react";
import GetPostSections from "../../components/homecomponents/getpostsection/GetPostsSection";

const Home = () => {
  return (
    <div>
      <GetPostSections />
    </div>
  );
};

export default Home;
