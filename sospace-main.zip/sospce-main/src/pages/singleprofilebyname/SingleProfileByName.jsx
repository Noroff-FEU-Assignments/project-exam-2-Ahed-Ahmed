import React from "react";
import { useGetProfileByNameQuery } from "../../features/profile/profileApiSlice";
import CircularProgress from "@mui/material/CircularProgress";
import NoAvatar from "../../assets/images/noprofile.jpeg";
import { useParams } from "react-router-dom";
import "./singleprofilebyname.scss";
const SingleProfileByName = () => {
  const { username } = useParams();
  const {
    data: profileByName,
    isLoading,
    isSuccess,
  } = useGetProfileByNameQuery(username);
  React.useEffect(() => {
    window.scrollTo(0, 0, { behavior: "smooth" });
  }, []);
  if (isLoading) {
    return (
      <div
        style={{
          width: "100%",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          height: "8vh",
        }}
      >
        <CircularProgress />
      </div>
    );
  }

  if (isSuccess) {
    return (
      <div className="singleprofile-container">
        <div className="card">
          <div className="image-info-container">
            <div className="image-container">
              {profileByName?.avatar !== null ? (
                <img src={profileByName?.avatar} alt={profileByName?.name} />
              ) : (
                <img src={NoAvatar} alt="user" />
              )}
            </div>
            <div className="info-container">
              <div className="email-container">{profileByName?.email}</div>
              <div className="username-container">{profileByName?.name}</div>
            </div>
          </div>
          <div className="sub-info-container">
            <div className="sub-info-count-container">
              <p>Followers </p>{" "}
              <span className="count-text">
                {profileByName?._count?.followers}
              </span>
            </div>
            <div className="sub-info-count-container">
              <p>Following </p>{" "}
              <span className="count-text">
                {profileByName?._count?.following}
              </span>
            </div>
            <div className="sub-info-count-container">
              <p>No.Posts </p>{" "}
              <span className="count-text">{profileByName?._count?.posts}</span>
            </div>
          </div>
        </div>
      </div>
    );
  }
};

export default SingleProfileByName;
