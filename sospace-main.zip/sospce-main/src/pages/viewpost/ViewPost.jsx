import React from "react";
import { useParams } from "react-router-dom";
import RateReviewOutlinedIcon from "@mui/icons-material/RateReviewOutlined";
import RepeatRoundedIcon from "@mui/icons-material/RepeatRounded";
import CircularProgress from "@mui/material/CircularProgress";
import { useGetCurrentUserSinglePostDataQuery } from "../../features/posts/PostApiSlice";
import NoProfile from "../../assets/images/noprofile.jpeg";
import "./viewpost.scss";
import { useGetPosts } from "../../customhooks/postshook/useGetPosts";
import Emojis from "../../components/generalcomponents/emojis/Emojis";
import RecentComments from "../../components/generalcomponents/recentcomments/RecentComments";
import Cookies from "js-cookie";
import { useAddComment } from "../../customhooks/postshook/useCommentOnPost";
import { useGeneralFunction } from "../../customhooks/generalhook/useGeneralFunction";
const ViewPost = () => {
  const currentUserString = Cookies.get("userData") || null;
  const currentUser = JSON.parse(currentUserString) || null;
  const { id } = useParams();
  const { data, isLoading, isSuccess } = 
    useGetCurrentUserSinglePostDataQuery(id);
  const { postDate, postTime } = useGetPosts();
  const { body, setBody, handleSubmit, isPostLoading } = useAddComment();
  const { handleGoBackProfile, handleViewProfileByName } = useGeneralFunction();
  React.useEffect(() => {
    window.scrollTo(0, 0, { behavior: "smooth" });
  }, []);

  if (isLoading) {
    return (
      <div
        style={{
          width: "100%",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          height: "8vh",
        }}
      >
        <CircularProgress />
      </div>
    );
  }
  if (isSuccess) {
    return (
      <div>
        <div className="main-single-post-container">
          <div className="main-info-container">
            <div className="top-container">
              <div className="left-container">
                <div className="image-name-container">
                  <div
                    className="image-container"
                    onClick={() => {
                      handleViewProfileByName(data?.author?.name);
                    }}
                  >
                    {data?.author?.avatar ? (
                      <img src={data?.author?.avatar} alt="" />
                    ) : (
                      <img src={NoProfile} alt="user" />
                    )}
                  </div>
                  <div
                    className="name-container"
                    onClick={() => {
                      handleViewProfileByName(data?.author?.name);
                    }}
                  >
                    <p>{data?.author?.name}</p>
                  </div>
                </div>
              </div>
              <div className="right-container">
                <div className="data-time-container">
                  <p>{postDate(data?.created)} &nbsp;&nbsp;</p>
                  <p>{postTime(data?.created)} &nbsp;&nbsp;</p>
                </div>
              </div>
            </div>

            <div className="bottom-container">
              <div className="topbottomcontainer">
                <div className="image-container">
                  <img src={data?.media} alt="user" />
                </div>
              </div>
              <div className="countscontainer">
                <div className="countsection">
                  <RateReviewOutlinedIcon />
                  <p>{data?._count?.comments}</p>
                </div>
                <div className="countsection">
                  <RepeatRoundedIcon />
                  <p>{data?._count?.reactions}</p>
                </div>
              </div>
              <div className="text-container">
                <div className="tagcontainer">
                  {data?.tags.map((tag, index) => (
                    <p key={index}>{tag}</p>
                  ))}
                </div>
                <div className="titlecontainer">
                  <h5>{data?.title}</h5>
                </div>
                <div className="descriptioncontainer">
                  <p>{data?.body}</p>
                </div>
              </div>
            </div>
            <div className="emoji-container">
              <Emojis postId={data?.id} />
            </div>
            <div className="comments-container">
              <RecentComments comments={data?.comments} />
            </div>
            <div className="replycontainer">
              <div className="currentuser" onClick={handleGoBackProfile}>
                <img src={currentUser?.avatar} alt="user" />
              </div>
              <form
                style={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                }}
              >
                <textarea
                  required
                  placeholder="comment here..."
                  rows={2}
                  onChange={(e) => setBody(e.target.value)}
                  name="body"
                  value={body}
                />

                <button
                  className="post-button"
                  type="submit"
                  disabled={isPostLoading}
                  onClick={(e) => handleSubmit(e, data.id)}
                >
                  {isPostLoading ? "Loading.." : "Post"}
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    );
  }
};

export default ViewPost;
