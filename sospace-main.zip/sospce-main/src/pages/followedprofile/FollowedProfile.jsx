import React from "react";

import FollowedAccount from "../../components/profilecomponents/currentuserfollowedaccount/FollowedAccount";

const FollowedProfile = () => {
  return (
    <div>
      <FollowedAccount />
    </div>
  );
};

export default FollowedProfile;
