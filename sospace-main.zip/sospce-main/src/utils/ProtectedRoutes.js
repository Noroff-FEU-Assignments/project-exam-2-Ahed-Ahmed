import React from "react";
import { Navigate, Outlet } from "react-router-dom";
import Cookies from "js-cookie";

const ProtectedRoutes = () => {
  const userDataString = Cookies.get("userData");

  if (userDataString) {
    const userData = JSON.parse(userDataString);
    const token = userData.accessToken;

    if (token) {
      return <Outlet />;
    }
  }

  return <Navigate to="/login" />;
};

export default ProtectedRoutes;
